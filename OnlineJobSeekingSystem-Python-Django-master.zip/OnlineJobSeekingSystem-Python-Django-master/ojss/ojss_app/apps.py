from django.apps import AppConfig


class OjssAppConfig(AppConfig):
    name = 'ojss_app'
